// data.js
const allTransactions = [
    { id: 1102, customer: "Võ Hoài An", employee: "Mai Thục Anh", amount: 250000, date: "06 Tháng 6 2024 9:00" },
    { id: 1199, customer: "Hoàng Thị Thắng", employee: "Nguyễn Văn Hùng", amount: 600000, date: "06 Tháng 6 2024 9:03" },
    { id: 1239, customer: "Nguyễn Huy Quang", employee: "Nguyễn Văn Hùng", amount: 934000, date: "06 Tháng 6 2024 9:10" },
    { id: 1677, customer: "Huỳnh Văn Nam", employee: "Mai Thục Anh", amount: 150000, date: "06 Tháng 6 2024 9:20" },
    { id: 1439, customer: "Nguyễn Hồng Minh", employee: "Mai Thục Anh", amount: 354000, date: "06 Tháng 6 2024 9:24" },
]