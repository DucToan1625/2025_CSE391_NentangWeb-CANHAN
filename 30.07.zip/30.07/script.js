// script.js
document.addEventListener('DOMContentLoaded', () => {
    const transactionTableBody = document.getElementById('transactionTableBody');
    const addTransactionModal = document.getElementById('addTransactionModal');
    const addTransactionForm = document.getElementById('addTransactionForm');
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
    const transactionSearchInput = document.getElementById('transactionSearchInput');
    const itemsPerPageSelect = document.getElementById('itemsPerPageSelect');
    const paginationLinksContainer = document.getElementById('paginationLinks');
    const paginationInfo = document.getElementById('paginationInfo');

    let currentTransactions = [...allTransactions]; // Dữ liệu hiện tại sau khi lọc/tìm kiếm
    let currentPage = 1;
    let itemsPerPage = parseInt(itemsPerPageSelect.value);

    // Hàm định dạng số tiền VND
    function formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    }

    // Hàm render bảng giao dịch
    function renderTransactions() {
        transactionTableBody.innerHTML = ''; // Xóa nội dung cũ
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const transactionsToDisplay = currentTransactions.slice(startIndex, endIndex);

        if (transactionsToDisplay.length === 0) {
            transactionTableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px;">Không có dữ liệu phù hợp.</td></tr>';
            renderPagination(0); // Cập nhật phân trang khi không có dữ liệu
            return;
        }

        transactionsToDisplay.forEach(transaction => {
            const row = transactionTableBody.insertRow();
            row.dataset.id = transaction.id; // Lưu ID vào dataset để dễ dàng truy cập
            row.innerHTML = `
                <td><input type="checkbox" class="row-checkbox" data-id="${transaction.id}"></td>
                <td class="actions">
                    <button class="action-icon edit-button" title="Chỉnh sửa"><i class="fas fa-edit"></i></button>
                    <button class="action-icon view-button" title="Xem chi tiết"><i class="fas fa-eye"></i></button>
                    <button class="action-icon delete-button" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                </td>
                <td>${transaction.id}</td>
                <td>${transaction.customer}</td>
                <td>${transaction.employee}</td>
                <td>${formatCurrency(transaction.amount)}</td>
                <td>${transaction.date}</td>
            `;

            // Thêm sự kiện cho nút xóa từng hàng
            row.querySelector('.delete-button').addEventListener('click', (e) => {
                e.stopPropagation(); // Ngăn sự kiện click lan ra hàng
                deleteTransaction(transaction.id);
            });
            // Thêm sự kiện cho nút sửa
            row.querySelector('.edit-button').addEventListener('click', (e) => {
                e.stopPropagation();
                editTransaction(transaction.id);
            });
            // Thêm sự kiện cho nút xem
            row.querySelector('.view-button').addEventListener('click', (e) => {
                e.stopPropagation();
                viewTransaction(transaction.id);
            });
        });

        updateSelectAllCheckbox();
        renderPagination(currentTransactions.length);
    }

    // Hàm render phân trang
    function renderPagination(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        paginationLinksContainer.innerHTML = '';

        // Nút Previous page
        const prevDoubleArrow = document.createElement('a');
        prevDoubleArrow.href = "#";
        prevDoubleArrow.classList.add('pagination-link');
        prevDoubleArrow.innerHTML = '&lt;&lt;';
        prevDoubleArrow.addEventListener('click', (e) => {
            e.preventDefault();
            if (currentPage > 1) {
                currentPage = 1; // Chuyển về trang đầu
                renderTransactions();
            }
        });
        paginationLinksContainer.appendChild(prevDoubleArrow);

        const prevArrow = document.createElement('a');
        prevArrow.href = "#";
        prevArrow.classList.add('pagination-link');
        prevArrow.innerHTML = '&lt;';
        prevArrow.addEventListener('click', (e) => {
            e.preventDefault();
            if (currentPage > 1) {
                currentPage--;
                renderTransactions();
            }
        });
        paginationLinksContainer.appendChild(prevArrow);

        // Các nút số trang
        const maxPageButtons = 6; // Số lượng nút trang hiển thị tối đa
        let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
        let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);

        if (endPage - startPage + 1 < maxPageButtons) {
            startPage = Math.max(1, endPage - maxPageButtons + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageLink = document.createElement('a');
            pageLink.href = "#";
            pageLink.classList.add('pagination-link');
            if (i === currentPage) {
                pageLink.classList.add('active');
            }
            pageLink.textContent = i;
            pageLink.addEventListener('click', (e) => {
                e.preventDefault();
                currentPage = i;
                renderTransactions();
            });
            paginationLinksContainer.appendChild(pageLink);
        }

        // Nút Next page
        const nextArrow = document.createElement('a');
        nextArrow.href = "#";
        nextArrow.classList.add('pagination-link');
        nextArrow.innerHTML = '&gt;';
        nextArrow.addEventListener('click', (e) => {
            e.preventDefault();
            if (currentPage < totalPages) {
                currentPage++;
                renderTransactions();
            }
        });
        paginationLinksContainer.appendChild(nextArrow);

        const nextDoubleArrow = document.createElement('a');
        nextDoubleArrow.href = "#";
        nextDoubleArrow.classList.add('pagination-link');
        nextDoubleArrow.innerHTML = '&gt;&gt;';
        nextDoubleArrow.addEventListener('click', (e) => {
            e.preventDefault();
            if (currentPage < totalPages) {
                currentPage = totalPages; // Chuyển về trang cuối
                renderTransactions();
            }
        });
        paginationLinksContainer.appendChild(nextDoubleArrow);


        // Cập nhật thông tin phân trang
        const startItem = totalItems === 0 ? 0 : (startIndex + 1);
        const endItem = Math.min(endIndex, totalItems);
        paginationInfo.textContent = `Hiển thị ${startItem}-${endItem} trong tổng số ${totalItems} kết quả (${totalPages} trang)`;
    }


    // Mở modal thêm giao dịch
    window.openAddTransactionModal = () => {
        addTransactionModal.style.display = 'flex'; // Sử dụng flex để căn giữa
        addTransactionForm.reset(); // Reset form khi mở
        // Tùy chỉnh nếu có chế độ chỉnh sửa (edit mode)
        addTransactionForm.dataset.editMode = 'false';
        addTransactionModal.querySelector('h2').textContent = 'Thêm giao dịch';
        addTransactionForm.querySelector('button[type="submit"]').textContent = 'Thêm';
    };

    // Đóng modal thêm giao dịch
    window.closeAddTransactionModal = () => {
        addTransactionModal.style.display = 'none';
    };

    // Xử lý submit form thêm/sửa giao dịch
    addTransactionForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const khachHang = document.getElementById('modalKhachHang').value;
        const nhanVien = document.getElementById('modalNhanVien').value;
        const soTien = parseInt(document.getElementById('modalSoTien').value);

        if (addTransactionForm.dataset.editMode === 'true') {
            const transactionId = parseInt(addTransactionForm.dataset.transactionId);
            const index = allTransactions.findIndex(t => t.id === transactionId);
            if (index !== -1) {
                allTransactions[index].customer = khachHang;
                allTransactions[index].employee = nhanVien;
                allTransactions[index].amount = soTien;
                // Cập nhật ngày mua nếu cần, hoặc giữ nguyên
            }
        } else {
            // Thêm giao dịch mới
            const newId = allTransactions.length > 0 ? Math.max(...allTransactions.map(t => t.id)) + 1 : 1;
            const now = new Date();
            const dateString = `${now.getDate()} Tháng ${now.getMonth() + 1} ${now.getFullYear()} ${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
            const newTransaction = {
                id: newId,
                customer: khachHang,
                employee: nhanVien,
                amount: soTien,
                date: dateString
            };
            allTransactions.push(newTransaction);
        }

        // Sau khi thêm/sửa, cập nhật lại currentTransactions (có thể cần áp dụng lại bộ lọc/tìm kiếm)
        applyFiltersAndSearch();
        closeAddTransactionModal();
    });

    // Chức năng sửa giao dịch
    function editTransaction(id) {
        const transaction = allTransactions.find(t => t.id === id);
        if (transaction) {
            document.getElementById('modalKhachHang').value = transaction.customer;
            document.getElementById('modalNhanVien').value = transaction.employee;
            document.getElementById('modalSoTien').value = transaction.amount;

            addTransactionModal.querySelector('h2').textContent = 'Chỉnh sửa giao dịch';
            addTransactionForm.querySelector('button[type="submit"]').textContent = 'Cập nhật';
            addTransactionForm.dataset.editMode = 'true';
            addTransactionForm.dataset.transactionId = id; // Lưu ID giao dịch đang sửa

            addTransactionModal.style.display = 'flex';
        }
    }

    // Chức năng xem giao dịch (đơn giản là alert thông tin)
    function viewTransaction(id) {
        const transaction = allTransactions.find(t => t.id === id);
        if (transaction) {
            alert(`
                Chi tiết giao dịch ID: ${transaction.id}
                Khách hàng: ${transaction.customer}
                Nhân viên: ${transaction.employee}
                Số tiền: ${formatCurrency(transaction.amount)}
                Ngày mua: ${transaction.date}
            `);
        }
    }

    // Chức năng xóa một giao dịch
    function deleteTransaction(id) {
        if (confirm(`Bạn có chắc chắn muốn xóa giao dịch ID ${id} này không?`)) {
            allTransactions = allTransactions.filter(t => t.id !== id);
            applyFiltersAndSearch(); // Cập nhật lại sau khi xóa
        }
    }

    // Xử lý checkbox chọn tất cả
    selectAllCheckbox.addEventListener('change', (e) => {
        const checkboxes = document.querySelectorAll('.row-checkbox');
        checkboxes.forEach(cb => {
            cb.checked = e.target.checked;
        });
    });

    // Cập nhật trạng thái checkbox chọn tất cả
    function updateSelectAllCheckbox() {
        const checkboxes = document.querySelectorAll('.row-checkbox');
        if (checkboxes.length === 0) {
            selectAllCheckbox.checked = false;
            selectAllCheckbox.disabled = true;
        } else {
            selectAllCheckbox.disabled = false;
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            selectAllCheckbox.checked = allChecked;
        }
    }

    // Lắng nghe sự kiện click trên các checkbox hàng để cập nhật checkbox "chọn tất cả"
    transactionTableBody.addEventListener('change', (e) => {
        if (e.target.classList.contains('row-checkbox')) {
            updateSelectAllCheckbox();
        }
    });

    // Xóa các bản ghi đã chọn
    deleteSelectedBtn.addEventListener('click', () => {
        const selectedIds = Array.from(document.querySelectorAll('.row-checkbox:checked'))
                               .map(cb => parseInt(cb.dataset.id));

        if (selectedIds.length === 0) {
            alert('Vui lòng chọn ít nhất một bản ghi để xóa.');
            return;
        }

        if (confirm(`Bạn có chắc chắn muốn xóa ${selectedIds.length} bản ghi đã chọn không?`)) {
            allTransactions = allTransactions.filter(t => !selectedIds.includes(t.id));
            selectAllCheckbox.checked = false; // Bỏ chọn tất cả sau khi xóa
            applyFiltersAndSearch(); // Cập nhật lại bảng
        }
    });

    // Chức năng tìm kiếm giao dịch
    transactionSearchInput.addEventListener('input', () => {
        currentPage = 1; // Reset về trang 1 khi tìm kiếm
        applyFiltersAndSearch();
    });

    // Chức năng thay đổi số lượng mục trên mỗi trang
    itemsPerPageSelect.addEventListener('change', (e) => {
        itemsPerPage = parseInt(e.target.value);
        currentPage = 1; // Reset về trang 1 khi thay đổi số mục hiển thị
        applyFiltersAndSearch();
    });

    // Chức năng sắp xếp bảng
    document.querySelectorAll('th[data-sort-by]').forEach(header => {
        header.addEventListener('click', () => {
            const sortBy = header.dataset.sortBy;
            let sortOrder = header.dataset.sortOrder === 'asc' ? 'desc' : 'asc';

            // Xóa trạng thái sắp xếp của các cột khác
            document.querySelectorAll('th[data-sort-by]').forEach(th => {
                if (th !== header) {
                    delete th.dataset.sortOrder;
                    th.querySelector('.fas.fa-sort').classList.remove('fa-sort-up', 'fa-sort-down');
                    th.querySelector('.fas.fa-sort').classList.add('fa-sort');
                }
            });

            // Cập nhật trạng thái sắp xếp cho cột hiện tại
            header.dataset.sortOrder = sortOrder;
            const sortIcon = header.querySelector('.fas.fa-sort');
            sortIcon.classList.remove('fa-sort');
            sortIcon.classList.add(sortOrder === 'asc' ? 'fa-sort-up' : 'fa-sort-down');

            currentTransactions.sort((a, b) => {
                let valA = a[sortBy];
                let valB = b[sortBy];

                if (sortBy === 'amount') {
                    valA = parseFloat(valA);
                    valB = parseFloat(valB);
                } else if (sortBy === 'id') {
                    valA = parseInt(valA);
                    valB = parseInt(valB);
                } else if (sortBy === 'date') {
                    // Chuyển đổi định dạng ngày sang đối tượng Date để so sánh
                    // Example: "06 Tháng 6 2024 9:00"
                    const parseDateString = (dateStr) => {
                        const parts = dateStr.match(/(\d+) Tháng (\d+) (\d+) (\d+):(\d+)/);
                        if (parts) {
                            // Month is 1-indexed in string, Date constructor expects 0-indexed
                            return new Date(parts[3], parts[2] - 1, parts[1], parts[4], parts[5]);
                        }
                        return new Date(dateStr); // Fallback for other formats
                    };
                    valA = parseDateString(valA);
                    valB = parseDateString(valB);
                }

                if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
                if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
                return 0;
            });
            renderTransactions();
        });
    });

    // Áp dụng các bộ lọc và tìm kiếm để cập nhật currentTransactions
    function applyFiltersAndSearch() {
        let filteredTransactions = [...allTransactions];
        const searchTerm = transactionSearchInput.value.toLowerCase().trim();

        if (searchTerm) {
            filteredTransactions = filteredTransactions.filter(t =>
                t.customer.toLowerCase().includes(searchTerm) ||
                t.employee.toLowerCase().includes(searchTerm) ||
                t.id.toString().includes(searchTerm) ||
                t.date.toLowerCase().includes(searchTerm) ||
                formatCurrency(t.amount).toLowerCase().includes(searchTerm)
            );
        }
        currentTransactions = filteredTransactions;
        renderTransactions();
    }


    // Khởi tạo bảng khi tải trang
    applyFiltersAndSearch();
});