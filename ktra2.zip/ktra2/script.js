// Lấy các phần tử DOM
const fullNameInput = document.getElementById("fullName");
const classNameInput = document.getElementById("className");
const errorFullName = document.getElementById("errorFullName");
const errorClassName = document.getElementById("errorClassName");
const notification = document.getElementById("notification");
const btnAdd = document.getElementById("btnAdd");
const btnUpdate = document.getElementById("btnUpdate");
const btnCancel = document.getElementById("btnCancel");

let editId = null;

// Hàm validate form
function validateForm() {
  let isValid = true;
  const fullName = fullNameInput.value.trim();
  const className = classNameInput.value.trim();

  if (fullName === "") {
    errorFullName.textContent = "Họ tên không được để trống";
    errorFullName.style.display = "block";
    isValid = false;
  } else if (fullName.length > 50) {
    errorFullName.textContent = "Họ tên không quá 50 ký tự";
    errorFullName.style.display = "block";
    isValid = false;
  } else {
    errorFullName.style.display = "none";
  }

  if (className === "") {
    errorClassName.textContent = "Lớp không được để trống";
    errorClassName.style.display = "block";
    isValid = false;
  } else {
    errorClassName.style.display = "none";
  }

  return isValid;
}

// Hiển thị thông báo
function showNotification(message) {
  notification.textContent = message;
  notification.style.display = "block";

  setTimeout(() => {
    notification.style.display = "none";
  }, 2000);
}

// Xử lý click Thêm Học sinh
btnAdd.addEventListener("click", () => {
  if (validateForm()) {
    showNotification("Thêm Học sinh thành công!");
    fullNameInput.value = "";
    classNameInput.value = "";
  }
});

// Xử lý click nút Sửa
document.querySelectorAll(".btn-edit").forEach((btn) => {
  btn.addEventListener("click", () => {
    editId = btn.getAttribute("data-id"); // Giả lập ID đang sửa
    // Giả lập lấy dữ liệu từ dòng đã chọn (cứng)
    fullNameInput.value = "Tên học sinh cũ";
    classNameInput.value = "Lớp cũ";

    // Chuyển chế độ sang "Cập nhật"
    btnAdd.style.display = "none";
    btnUpdate.style.display = "inline-block";
    btnCancel.style.display = "inline-block";
  });
});

// Xử lý click nút Cập nhật
btnUpdate.addEventListener("click", () => {
  if (validateForm()) {
    showNotification("Cập nhật thành công!");
    fullNameInput.value = "";
    classNameInput.value = "";
    btnAdd.style.display = "inline-block";
    btnUpdate.style.display = "none";
    btnCancel.style.display = "none";
  }
});

// Xử lý click nút Hủy
btnCancel.addEventListener("click", () => {
  fullNameInput.value = "";
  classNameInput.value = "";
  errorFullName.style.display = "none";
  errorClassName.style.display = "none";
  btnAdd.style.display = "inline-block";
  btnUpdate.style.display = "none";
  btnCancel.style.display = "none";
});
// Xử lý click nút Xóa
document.querySelectorAll(".btn-delete").forEach((btn) => {
  btn.addEventListener("click", () => {
    if (window.confirm("Bạn có chắc muốn xóa Học sinh này?")) {
      showNotification("Xóa thành công!");
    }
  });
});