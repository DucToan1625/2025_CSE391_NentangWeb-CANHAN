$(document).ready(function() {

    // Dữ liệu mẫu
    let data = [
        { id: 1, stt: 1, ten: "Mai", hoDem: "Thục Anh", diaChi: "23 Hoàng Đạo Thúy, Thanh Xuân, Hà Nội", hoatDong: true },
        { id: 2, stt: 2, ten: "Hoàng", hoDem: "Sinh Hồng", diaChi: "23 Hoàng Đạo Thúy, Thanh Xuân, Hà Nội", hoatDong: false },
        { id: 3, stt: 3, ten: "Tình", hoDem: "Mai Trung", diaChi: "1411 Đường Láng, Cầu Giấy, Hà Nội", hoatDong: true },
        { id: 4, stt: 4, ten: "Hồng", hoDem: "Nguyễn Văn", diaChi: "1411 Đường Láng, Cầu Giấy, Hà Nội", hoatDong: false }
    ];

    // Hàm render dữ liệu ra bảng
    function renderTable(dataToRender) {
        const $tbody = $('.data-table tbody');
        $tbody.empty(); // Xóa dữ liệu cũ
        dataToRender.forEach(item => {
            const statusIcon = item.hoatDong 
                ? '<i class="fas fa-check status-icon"></i>' 
                : '<i class="fas fa-times status-icon"></i>';
            const row = `
                <tr data-id="${item.id}">
                    <td><input type="checkbox" class="select-row"></td>
                    <td class="action-buttons">
                        <button class="btn btn-view" title="Xem"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-edit" title="Sửa"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-delete" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                    </td>
                    <td>${item.stt}</td>
                    <td>${item.ten}</td>
                    <td>${item.hoDem}</td>
                    <td>${item.diaChi}</td>
                    <td>${statusIcon}</td>
                </tr>
            `;
            $tbody.append(row);
        });
        $('#pagination-summary').text(`Kết quả 1 đến ${dataToRender.length}`);
    }

    // Khởi tạo bảng ban đầu
    renderTable(data);

    // Xử lý nút "Thêm mới"
    $('#add-new-btn').click(function() {
        $('#data-id').val('');
        $('#data-form')[0].reset();
        $('.modal-title').text('Thêm Nhân viên');
        $('#save-btn').text('Thêm');
        $('#myModal').removeClass('hidden').addClass('show'); // Thêm class 'show' để hiển thị
    });

    // Xử lý nút "Sửa"
    $(document).on('click', '.btn-edit', function() {
        const id = $(this).closest('tr').data('id');
        const item = data.find(i => i.id === id);
        
        if (item) {
            $('#data-id').val(item.id);
            $('#ten').val(item.ten);
            $('#ho-dem').val(item.hoDem);
            $('#dia-chi').val(item.diaChi);
            
            $('.modal-title').text('Sửa Nhân viên');
            $('#save-btn').text('Lưu');
            $('#myModal').removeClass('hidden').addClass('show'); // Thêm class 'show' để hiển thị
        }
    });

    // Xử lý nút "Xóa"
    $(document).on('click', '.btn-delete', function() {
        if (confirm('Bạn có chắc chắn muốn xóa mục này?')) {
            const id = $(this).closest('tr').data('id');
            data = data.filter(item => item.id !== id);
            renderTable(data);
        }
    });

    // Xử lý form thêm/sửa
    $('#data-form').submit(function(e) {
        e.preventDefault();
        
        const id = $('#data-id').val();
        const newItem = {
            ten: $('#ten').val(),
            hoDem: $('#ho-dem').val(),
            diaChi: $('#dia-chi').val(),
        };

        if (id) {
            // Sửa
            const index = data.findIndex(item => item.id === parseInt(id));
            if (index !== -1) {
                Object.assign(data[index], newItem);
            }
        } else {
            // Thêm mới
            newItem.id = Date.now();
            newItem.stt = data.length > 0 ? Math.max(...data.map(d => d.stt)) + 1 : 1;
            newItem.hoatDong = false;
            data.push(newItem);
        }

        renderTable(data);
        $('#myModal').addClass('hidden').removeClass('show');
    });
    
    // Xử lý nút "Hủy" và đóng modal
    $('#cancel-btn').click(function() {
        $('#myModal').addClass('hidden').removeClass('show');
    });

    // Đóng modal bằng nút close hoặc click ra ngoài
    $('.close-btn, .modal').click(function(e) {
        if ($(e.target).is('.close-btn') || $(e.target).is('.modal')) {
            $('#myModal').addClass('hidden').removeClass('show');
        }
    });
    
    // Ngăn chặn sự kiện click lan truyền ra modal background
    $('.modal-content').click(function(e) {
        e.stopPropagation();
    });

    // Xử lý tìm kiếm theo tên
    $('#search-by-name').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        const filteredData = data.filter(item => 
            item.ten.toLowerCase().includes(searchTerm) || 
            item.hoDem.toLowerCase().includes(searchTerm)
        );
        renderTable(filteredData);
    });
    
    // Xử lý sắp xếp cột
    $('.sortable').click(function() {
        const sortKey = $(this).data('sort');
        const isAscending = $(this).hasClass('asc');

        // Xóa tất cả các class sắp xếp cũ
        $('.sortable').removeClass('asc desc');
        $(this).addClass(isAscending ? 'desc' : 'asc');

        data.sort((a, b) => {
            let valA, valB;
            switch(sortKey) {
                case 'stt':
                    valA = a.stt;
                    valB = b.stt;
                    break;
                case 'ten':
                    valA = a.ten.toLowerCase();
                    valB = b.ten.toLowerCase();
                    break;
                case 'ho-dem':
                    valA = a.hoDem.toLowerCase();
                    valB = b.hoDem.toLowerCase();
                    break;
                case 'dia-chi':
                    valA = a.diaChi.toLowerCase();
                    valB = b.diaChi.toLowerCase();
                    break;
            }
            if (valA < valB) return isAscending ? -1 : 1;
            if (valA > valB) return isAscending ? 1 : -1;
            return 0;
        });

        renderTable(data);
    });

    // Xử lý chọn tất cả
    $('#select-all').change(function() {
        $('.select-row').prop('checked', this.checked);
    });
    
    // Xử lý chọn từng hàng
    $(document).on('change', '.select-row', function() {
        if ($('.select-row:checked').length === $('.select-row').length) {
            $('#select-all').prop('checked', true);
        } else {
            $('#select-all').prop('checked', false);
        }
    });

});