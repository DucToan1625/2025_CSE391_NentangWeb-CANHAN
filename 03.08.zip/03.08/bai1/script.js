$(document).ready(function() {

    // Dữ liệu mẫu mới cho nhân viên
    let data = [
        { id: 1, name: "Thomas Hardy", email: "thomashardy@mail.com", address: "89 Chiaroscuro Rd, Portland, USA", phone: "(171) 555-2222" },
        { id: 2, name: "Dominique Perrier", email: "dominiqueperrier@mail.com", address: "Obere Str. 57, Berlin, Germany", phone: "(313) 555-5735" },
        { id: 3, name: "Maria Anders", email: "mariaanders@mail.com", address: "25, rue Lauriston, Paris, France", phone: "(503) 555-9931" },
        { id: 4, name: "Fran Wilson", email: "franwilson@mail.com", address: "C/ Araquil, 67, Madrid, Spain", phone: "(204) 619-5731" },
        { id: 5, name: "Martin Blank", email: "martinblank@mail.com", address: "Via Monte Bianco 34, Turin, Italy", phone: "(480) 631-2097" },
        { id: 6, name: "Annabelle Smith", email: "annabelle@mail.com", address: "123 Main St, New York, USA", phone: "(123) 456-7890" },
        { id: 7, name: "Peter Jones", email: "peterj@mail.com", address: "456 Side Rd, London, UK", phone: "(098) 765-4321" },
        { id: 8, name: "Laura Croft", email: "laurac@mail.com", address: "789 High St, Sydney, Australia", phone: "(041) 234-5678" }
    ];
    let currentPage = 1;
    let itemsPerPage = 5; // Mặc định là 5 mục trên mỗi trang theo hình ảnh
    let currentData = data; // Dữ liệu hiện tại sau khi tìm kiếm/sắp xếp

    // Hàm render dữ liệu ra bảng
    function renderTable() {
        const $tbody = $('.data-table tbody');
        $tbody.empty();
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const dataToRender = currentData.slice(startIndex, endIndex);

        dataToRender.forEach(item => {
            const row = `
                <tr data-id="${item.id}">
                    <td><input type="checkbox" class="select-row"></td>
                    <td>${item.name}</td>
                    <td>${item.email}</td>
                    <td>${item.address}</td>
                    <td>${item.phone}</td>
                    <td class="action-buttons">
                        <button class="btn btn-edit" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                        <button class="btn btn-delete" title="Delete"><i class="fas fa-trash-alt"></i></button>
                    </td>
                </tr>
            `;
            $tbody.append(row);
        });

        // Cập nhật thông tin phân trang
        const startItem = currentData.length > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(endIndex, currentData.length);
        $('#pagination-summary').text(`Showing ${startItem} out of ${currentData.length} entries`);
        
        const totalPages = Math.ceil(currentData.length / itemsPerPage);
        renderPaginationControls(totalPages);
        
        // Cập nhật trạng thái nút "Delete"
        const selectedRows = $('.select-row:checked').length;
        if (selectedRows > 0) {
            $('#delete-selected-btn').show();
        } else {
            $('#delete-selected-btn').hide();
        }
    }

    // Hàm render nút phân trang
    function renderPaginationControls(totalPages) {
        const $paginationControls = $('.pagination-controls');
        $paginationControls.empty();
        
        $paginationControls.append(`<a href="#" class="page-link prev-page ${currentPage === 1 ? 'disabled' : ''}">Previous</a>`);
        
        // Chỉ hiển thị 5 trang
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, currentPage + 2);
        
        // Điều chỉnh để luôn hiển thị 5 trang nếu có đủ
        if (endPage - startPage < 4) {
            if (currentPage < 3) endPage = Math.min(5, totalPages);
            if (currentPage > totalPages - 2) startPage = Math.max(1, totalPages - 4);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            $paginationControls.append(`<a href="#" class="page-link ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</a>`);
        }
        
        $paginationControls.append(`<a href="#" class="page-link next-page ${currentPage === totalPages ? 'disabled' : ''}">Next</a>`);
    }

    // Khởi tạo bảng ban đầu
    renderTable();

    // Xử lý click vào các nút phân trang
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
        const $this = $(this);
        if ($this.hasClass('disabled') || $this.hasClass('active')) return;
        
        if ($this.hasClass('prev-page')) {
            if (currentPage > 1) {
                currentPage--;
            }
        } else if ($this.hasClass('next-page')) {
            const totalPages = Math.ceil(currentData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
            }
        } else {
            currentPage = parseInt($this.data('page'));
        }
        renderTable();
    });

    // Hiển thị/Ẩn modal
    function showModal() {
        $('#myModal').removeClass('hidden').addClass('show');
    }

    function hideModal() {
        $('#myModal').addClass('hidden').removeClass('show');
    }

    // Xử lý nút "Add New Employee"
    $('#add-new-btn').click(function() {
        $('#data-id').val('');
        $('#data-form')[0].reset();
        $('.modal-title').text('Add Employee');
        $('#save-btn').text('Add');
        showModal();
    });

    // Xử lý nút "Edit"
    $(document).on('click', '.btn-edit', function() {
        const id = $(this).closest('tr').data('id');
        const item = data.find(i => i.id === id);
        
        if (item) {
            $('#data-id').val(item.id);
            $('#name').val(item.name);
            $('#email').val(item.email);
            $('#address').val(item.address);
            $('#phone').val(item.phone);
            
            $('.modal-title').text('Edit Employee');
            $('#save-btn').text('Save');
            showModal();
        }
    });

    // Xử lý nút "Delete"
    $(document).on('click', '.btn-delete', function() {
        if (confirm('Are you sure you want to delete this employee?')) {
            const id = $(this).closest('tr').data('id');
            data = data.filter(item => item.id !== id);
            currentData = currentData.filter(item => item.id !== id);
            renderTable();
        }
    });
    
    // Xử lý nút xóa hàng loạt
    $('#delete-selected-btn').click(function() {
        const selectedIds = $('.select-row:checked').map(function() {
            return $(this).closest('tr').data('id');
        }).get();
        
        if (selectedIds.length === 0) {
            alert('Please select at least one employee to delete.');
            return;
        }

        if (confirm(`Are you sure you want to delete ${selectedIds.length} selected employee(s)?`)) {
            data = data.filter(item => !selectedIds.includes(item.id));
            currentData = currentData.filter(item => !selectedIds.includes(item.id));
            renderTable();
        }
    });

    // Xử lý form thêm/sửa
    $('#data-form').submit(function(e) {
        e.preventDefault();
        
        const id = $('#data-id').val();
        const newItem = {
            name: $('#name').val(),
            email: $('#email').val(),
            address: $('#address').val(),
            phone: $('#phone').val()
        };

        if (id) {
            // Sửa
            const index = data.findIndex(item => item.id === parseInt(id));
            if (index !== -1) {
                Object.assign(data[index], newItem);
            }
        } else {
            // Thêm mới
            newItem.id = Date.now();
            data.push(newItem);
        }

        currentData = data;
        currentPage = 1;
        renderTable();
        hideModal();
    });
    
    // Xử lý nút "Cancel" và đóng modal
    $('#cancel-btn').click(function() {
        hideModal();
    });

    // Đóng modal bằng nút close hoặc click ra ngoài
    $('.close-btn, .modal').click(function(e) {
        if ($(e.target).is('.close-btn') || $(e.target).is('.modal')) {
            hideModal();
        }
    });
    
    // Ngăn chặn sự kiện click lan truyền ra modal background
    $('.modal-content').click(function(e) {
        e.stopPropagation();
    });
    
    // Xử lý chọn tất cả
    $('#select-all').change(function() {
        $('.select-row').prop('checked', this.checked);
        renderTable(); // Cập nhật trạng thái nút xóa
    });
    
    // Xử lý chọn từng hàng
    $(document).on('change', '.select-row', function() {
        const allChecked = $('.select-row').length === $('.select-row:checked').length;
        $('#select-all').prop('checked', allChecked);
        renderTable(); // Cập nhật trạng thái nút xóa
    });

    // Xử lý tìm kiếm
    $('#search-by-name').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        currentData = data.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.email.toLowerCase().includes(searchTerm)
        );
        currentPage = 1;
        renderTable();
    });

    // Xử lý sắp xếp cột
    $('.sortable').click(function() {
        const sortKey = $(this).data('sort');
        const isAscending = $(this).hasClass('asc');

        $('.sortable').removeClass('asc desc');
        $(this).addClass(isAscending ? 'desc' : 'asc');

        currentData.sort((a, b) => {
            let valA, valB;
            switch(sortKey) {
                case 'name':
                    valA = a.name.toLowerCase();
                    valB = b.name.toLowerCase();
                    break;
                case 'email':
                    valA = a.email.toLowerCase();
                    valB = b.email.toLowerCase();
                    break;
                case 'address':
                    valA = a.address.toLowerCase();
                    valB = b.address.toLowerCase();
                    break;
                case 'phone':
                    valA = a.phone.toLowerCase();
                    valB = b.phone.toLowerCase();
                    break;
            }
            if (valA < valB) return isAscending ? -1 : 1;
            if (valA > valB) return isAscending ? 1 : -1;
            return 0;
        });

        renderTable();
    });
});