$(document).ready(function() {

    // Dữ liệu mẫu mới cho giao dịch
    let data = [
        { id: 1102, khachHang: "Võ Hoài Ân", nhanVien: "Mai Thục Anh", soTien: 250000, ngayMua: "06 Tháng 6 2024 9:00" },
        { id: 1199, khachHang: "Hoàng Thị Thắng", nhanVien: "Nguyễn Văn Hồng", soTien: 600000, ngayMua: "06 Tháng 6 2024 9:03" },
        { id: 1299, khachHang: "Nguyễn Huy Quang", nhanVien: "Nguyễn Văn Hồng", soTien: 934000, ngayMua: "06 Tháng 6 2024 9:10" },
        { id: 1677, khachHang: "Huỳnh Văn Nam", nhanVien: "Mai Thục Anh", soTien: 150000, ngayMua: "06 Tháng 6 2024 9:20" },
        { id: 1439, khachHang: "Nguyễn Hồng Minh", nhanVien: "Mai Thục Anh", soTien: 354000, ngayMua: "06 Tháng 6 2024 9:24" },
        // Thêm dữ liệu mẫu để thử nghiệm phân trang
        { id: 1500, khachHang: "Trần Văn A", nhanVien: "Lê Thị B", soTien: 100000, ngayMua: "06 Tháng 6 2024 10:00" },
        { id: 1501, khachHang: "Phạm Văn C", nhanVien: "Mai Thục Anh", soTien: 200000, ngayMua: "06 Tháng 6 2024 10:05" },
        { id: 1502, khachHang: "Đỗ Thị D", nhanVien: "Nguyễn Văn Hồng", soTien: 300000, ngayMua: "06 Tháng 6 2024 10:10" },
        { id: 1503, khachHang: "Ngô Văn E", nhanVien: "Mai Thục Anh", soTien: 400000, ngayMua: "06 Tháng 6 2024 10:15" },
        { id: 1504, khachHang: "Vũ Thị F", nhanVien: "Lê Thị B", soTien: 500000, ngayMua: "06 Tháng 6 2024 10:20" }
    ];
    let currentPage = 1;
    let itemsPerPage = parseInt($('#results-per-page').val());
    let currentData = data; // Dữ liệu hiện tại sau khi tìm kiếm/sắp xếp

    // Hàm format số tiền
    function formatCurrency(number) {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(number);
    }

    // Hàm render dữ liệu ra bảng
    function renderTable() {
        const $tbody = $('.data-table tbody');
        $tbody.empty();
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const dataToRender = currentData.slice(startIndex, endIndex);

        dataToRender.forEach(item => {
            const row = `
                <tr data-id="${item.id}">
                    <td><input type="checkbox" class="select-row"></td>
                    <td class="action-buttons">
                        <button class="btn btn-view" title="Xem"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-edit" title="Sửa"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-delete" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                    </td>
                    <td>${item.id}</td>
                    <td>${item.khachHang}</td>
                    <td>${item.nhanVien}</td>
                    <td>${formatCurrency(item.soTien)}</td>
                    <td>${item.ngayMua}</td>
                </tr>
            `;
            $tbody.append(row);
        });

        // Cập nhật thông tin phân trang
        const totalPages = Math.ceil(currentData.length / itemsPerPage);
        const startItem = currentData.length > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(endIndex, currentData.length);
        $('#pagination-summary').text(`Kết quả ${startItem} đến ${endItem} trong tổng ${currentData.length}`);
        renderPaginationControls(totalPages);
    }

    // Hàm render nút phân trang
    function renderPaginationControls(totalPages) {
        const $paginationControls = $('.pagination-controls');
        $paginationControls.empty();
        
        $paginationControls.append(`<a href="#" class="page-link prev-page ${currentPage === 1 ? 'disabled' : ''}"><i class="fas fa-chevron-left"></i></a>`);
        
        for (let i = 1; i <= totalPages; i++) {
            $paginationControls.append(`<a href="#" class="page-link ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</a>`);
        }
        
        $paginationControls.append(`<a href="#" class="page-link next-page ${currentPage === totalPages ? 'disabled' : ''}"><i class="fas fa-chevron-right"></i></a>`);
    }

    // Khởi tạo bảng ban đầu
    renderTable();

    // Xử lý thay đổi số kết quả mỗi trang
    $('#results-per-page').change(function() {
        itemsPerPage = parseInt($(this).val());
        currentPage = 1;
        renderTable();
    });

    // Xử lý click vào các nút phân trang
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
        const $this = $(this);
        if ($this.hasClass('disabled')) return;
        
        if ($this.hasClass('prev-page')) {
            if (currentPage > 1) {
                currentPage--;
            }
        } else if ($this.hasClass('next-page')) {
            const totalPages = Math.ceil(currentData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
            }
        } else {
            currentPage = parseInt($this.data('page'));
        }
        renderTable();
    });


    // Hiển thị/Ẩn modal
    function showModal() {
        $('#myModal').removeClass('hidden').addClass('show');
    }

    function hideModal() {
        $('#myModal').addClass('hidden').removeClass('show');
    }

    // Xử lý nút "Thêm"
    $('#add-new-btn').click(function() {
        $('#data-id').val('');
        $('#data-form')[0].reset();
        $('.modal-title').text('Thêm giao dịch');
        $('#save-btn').text('Thêm');
        showModal();
    });

    // Xử lý nút "Sửa"
    $(document).on('click', '.btn-edit', function() {
        const id = $(this).closest('tr').data('id');
        const item = data.find(i => i.id === id);
        
        if (item) {
            $('#data-id').val(item.id);
            $('#khach-hang').val(item.khachHang);
            $('#nhan-vien').val(item.nhanVien);
            $('#so-tien').val(item.soTien);
            
            $('.modal-title').text('Sửa giao dịch');
            $('#save-btn').text('Lưu');
            showModal();
        }
    });

    // Xử lý nút "Xóa"
    $(document).on('click', '.btn-delete', function() {
        if (confirm('Bạn có chắc chắn muốn xóa giao dịch này?')) {
            const id = $(this).closest('tr').data('id');
            data = data.filter(item => item.id !== id);
            currentData = currentData.filter(item => item.id !== id);
            renderTable();
        }
    });
    
    // Xử lý nút xóa hàng loạt
    $('#delete-selected-btn').click(function() {
        const selectedIds = $('.select-row:checked').map(function() {
            return $(this).closest('tr').data('id');
        }).get();
        
        if (selectedIds.length === 0) {
            alert('Vui lòng chọn ít nhất một giao dịch để xóa.');
            return;
        }

        if (confirm(`Bạn có chắc chắn muốn xóa ${selectedIds.length} giao dịch đã chọn?`)) {
            data = data.filter(item => !selectedIds.includes(item.id));
            currentData = currentData.filter(item => !selectedIds.includes(item.id));
            renderTable();
        }
    });

    // Xử lý nút xóa tất cả
    $(document).on('click', '.delete-all-btn', function() {
        if (confirm('Bạn có chắc chắn muốn xóa tất cả các giao dịch đã chọn?')) {
            $('.select-row').prop('checked', true);
            $('#delete-selected-btn').click();
        }
    });

    // Xử lý form thêm/sửa
    $('#data-form').submit(function(e) {
        e.preventDefault();
        
        const id = $('#data-id').val();
        const newItem = {
            khachHang: $('#khach-hang').val(),
            nhanVien: $('#nhan-vien').val(),
            soTien: parseFloat($('#so-tien').val()),
        };

        if (id) {
            // Sửa
            const index = data.findIndex(item => item.id === parseInt(id));
            if (index !== -1) {
                Object.assign(data[index], newItem);
            }
        } else {
            // Thêm mới
            newItem.id = Date.now();
            newItem.ngayMua = new Date().toLocaleString('vi-VN');
            data.push(newItem);
        }

        currentData = data; // Cập nhật lại dữ liệu hiện tại
        currentPage = 1; // Quay về trang đầu tiên
        renderTable();
        hideModal();
    });
    
    // Xử lý nút "Hủy" và đóng modal
    $('#cancel-btn').click(function() {
        hideModal();
    });

    // Đóng modal bằng nút close hoặc click ra ngoài
    $('.close-btn, .modal').click(function(e) {
        if ($(e.target).is('.close-btn') || $(e.target).is('.modal')) {
            hideModal();
        }
    });
    
    // Ngăn chặn sự kiện click lan truyền ra modal background
    $('.modal-content').click(function(e) {
        e.stopPropagation();
    });

    // Xử lý tìm kiếm
    $('#search-by-id').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        currentData = data.filter(item => item.id.toString().includes(searchTerm));
        currentPage = 1;
        renderTable();
    });
    
    // Xử lý sắp xếp cột
    $('.sortable').click(function() {
        const sortKey = $(this).data('sort');
        const isAscending = $(this).hasClass('asc');

        $('.sortable').removeClass('asc desc');
        $(this).addClass(isAscending ? 'desc' : 'asc');

        currentData.sort((a, b) => {
            let valA, valB;
            switch(sortKey) {
                case 'id':
                    valA = a.id;
                    valB = b.id;
                    break;
                case 'khach-hang':
                    valA = a.khachHang.toLowerCase();
                    valB = b.khachHang.toLowerCase();
                    break;
                case 'nhan-vien':
                    valA = a.nhanVien.toLowerCase();
                    valB = b.nhanVien.toLowerCase();
                    break;
                case 'so-tien':
                    valA = a.soTien;
                    valB = b.soTien;
                    break;
                case 'ngay-mua':
                    valA = new Date(a.ngayMua).getTime();
                    valB = new Date(b.ngayMua).getTime();
                    break;
            }
            if (valA < valB) return isAscending ? -1 : 1;
            if (valA > valB) return isAscending ? 1 : -1;
            return 0;
        });

        renderTable();
    });

    // Xử lý chọn tất cả
    $(document).on('click', '.delete-all-btn', function() {
         const isChecked = $('#select-all').prop('checked');
         $('.select-row').prop('checked', !isChecked);
         $('#select-all').prop('checked', !isChecked);
    });
    
    // Xử lý chọn từng hàng
    $(document).on('change', '.select-row', function() {
        const allChecked = $('.select-row').length === $('.select-row:checked').length;
        $('#select-all').prop('checked', allChecked);
    });

});