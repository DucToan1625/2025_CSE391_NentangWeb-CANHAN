document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("employeeForm");
  const tableBody = document.getElementById("employeeTableBody");

  // Khởi tạo mảng employees từ sessionStorage hoặc data.js
  
  let employees = [];
  const temp = sessionStorage.getItem("employees");
  if (temp) {
    try {
      employees = JSON.parse(temp);
      console.log("Loaded employees from sessionStorage:", employees);
    } catch (error) {
      console.error("Error parsing sessionStorage data:", error);
    }
  } else if (typeof employeeData !== "undefined" && Array.isArray(employeeData)) {
    employees = JSON.parse(JSON.stringify(employeeData));
    sessionStorage.setItem("employees", JSON.stringify(employees));
    console.log("Initialized employees from employeeData:", employees);
  } else {
    console.log("No data found in sessionStorage or employeeData, starting with empty array");
  }
  
  // Hàm hiển thị danh sách sách
  function renderTable() {
    if (!tableBody) {
      console.warn("Table body not found");
      return;
    }
    tableBody.innerHTML = "";
    employees.forEach(emp => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${emp.id}</td>
        <td>${emp.name}</td>
        <td>${emp.phone}</td>
        <td>${emp.position}</td>
        <td>${emp.email}</td>
        <td>
          <button class="btn btn-sm btn-warning me-1" onclick="editemployee(${emp.id})">Sửa</button>
          <button class="btn btn-sm btn-danger" onclick="deleteemployee(${emp.id})">Xoá</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
    console.log("Rendered table with employees:", employees);
  }

  if (tableBody) renderTable();

  // Thêm / Sửa sách (trên add-employee.html)
  if (form) {
    // Nếu có dữ liệu cần sửa
    const editData = sessionStorage.getItem("editData");
    if (editData) {
      try {
        const emp = JSON.parse(editData);
        document.getElementById("name").value = emp.name || "";
        document.getElementById("phone").value = emp.phone || "";
        document.getElementById("position").value = emp.position || "";
        document.getElementById("email").value = emp.email || "";
        document.getElementById("editId").value = emp.id || "";
        sessionStorage.removeItem("editData");
        console.log("Loaded edit data:", emp);
      } catch (error) {
        console.error("Error parsing editData:", error);
      }
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      console.log("Form submitted");

      const name = document.getElementById("name")?.value.trim();
        const phone = document.getElementById("phone")?.value.trim();
        const position = document.getElementById("position")?.value.trim();
        const email = document.getElementById("email")?.value.trim();
      const editId = document.getElementById("editId")?.value.trim();
      if (!name || !phone|| !position || !email||!document.getElementById("name")) {
        console.error("Form fields are missing or ty");
        alert("Vui lòng nhập đầy đủ thông tin.");
        return;
      }

      if (!validateForm(name,phone, position, email)) {
        console.log("Form validation failed");
        return;
      }

      if (editId) {
        // Chỉnh sửa nhân viên
        const index = employees.findIndex(emp => emp.id == Number(editId));
        if (index !== -1) {
          employees[index] = { id:  Number(editId),name,phone, position, email };
          console.log("Edited employee:", employees[index]);
        } else {
          console.error("employee with ID not found:", editId);
        }
      } else {
        // Thêm sách mới với id tự động tăng từ 1
        let newId = 1;
        if (employees.length > 0) {
          newId = Math.max(...employees.map(b => Number(b.id))) + 1;
        }
        const newemployee = { id: newId, name,phone, position, email };
        employees.push(newemployee);
        console.log("Added new employee:", newemployee);
      }

      // Lưu vào sessionStorage
      try {
        sessionStorage.setItem("employees", JSON.stringify(employees));
        console.log("empved employees to sessionStorage:", employees);
        // Chuyển hướng empu khi lưu thành công
        renderTable();
        hideAddemployeePopup();
      } catch (error) {
        console.error("Error empving to sessionStorage:", error);
        alert("Có lỗi khi lưu dữ liệu. Vui lòng thử lại.");
      }
    });
  } else {
    console.warn("Form not found");
  }

  // Validate form
 function validateForm(name,phone, position, email) {
  // Kiểm tra các trường không rỗng
    if (!name || !phone || !position || !email) {
    alert("Vui lòng điền đầy đủ thông tin.");
    return false;
    }
    const phonePattern = /^0\d{9}$/;
    if (!phonePattern.test(phone)) {
        alert("Vui lòng nhập số điện thoại hợp lệ (bắt đầu bằng 0 và có 10 chữ số).");
        return false;
        }
    // Kiểm tra định dạng email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert("Vui lòng nhập địa chỉ email hợp lệ.");
      return false;
    }
  return true;
  
}


  // Xóa sách
  window.deleteemployee = function (id) {
    
    if (confirm("Bạn có chắc chắn muốn xóa nhân viên này không?")) {
        employees = employees.filter(emp => emp.id !== id);
        sessionStorage.setItem("employees", JSON.stringify(employees));
        console.log("Deleted employee with ID:", id);
        renderTable(); // Cập nhật lại bảng
    }
  };

  // Sửa sách
  window.editemployee = function (id) {
  const emp = employees.find(e => e.id === Number(id));
  if (emp) {
    // Đổ dữ liệu lên form popup
    showAddemployeePopup();
    document.querySelector('.form-popup h2').textContent = "Sửa Sách";
    document.getElementById("editId").value = emp.id || "";
    document.getElementById("name").value = emp.name || "";
    document.getElementById("phone").value = emp.phone || "";
    document.getElementById("position").value = emp.position || "";
    document.getElementById("email").value = emp.email || "";

    
  } else {
    console.error("employee not found for editing:", id);
  }
};
// Tìm kiếm sách
document.getElementById('searchBtn').addEventListener('click', function() {
    const searchValue = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#employeeTableBody tr');

    rows.forEach(row => {
        const cells = row.getElementsByTagName('td');
        let found = false;

        for (let i = 0; i < cells.length - 1; i++) { 
            if (cells[i].textContent.toLowerCase().includes(searchValue)) {
                found = true;
                break;
            }
        }

        row.style.display = found ? '' : 'none';
    });
});



});
