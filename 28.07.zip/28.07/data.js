const employeeData = [
  {
    id: 1,
    name: "John Doe",
    phone: "0234567890",
    position: "Developer",
    email: "jd@gmail.com"

  },
    {
    id: 2,
    name: "Jane Smith",
    phone: "0987654321",
    position: "Manager",
    email: "jane@gmail.com"

  },
  {
    id: 3,
    name: "Alice Johnson",
    phone: "0123456789",
    position: "Designer",
    email: "jhon@gmail.com"

  },
  {
    id: 4,
    name: "Bob Brown",
    phone: "0876543210",
    position: "Tester",
    email: "bro@gmail.com"

  },
  {
    id: 5,
    name: "Charlie White",
    phone: "0456789012",
    position: "Analyst",
    email: "whi@gmail.com"

  },
];